#!/bin/bash

# ------------------------------------------------
#  Script permettant de recuperer le nombre de ventes par minute 
#  pour les cartes graphiques dont les modeles sont rtx3060 , rtx3070, ..
# 
#  Auteur : Zeinab MADOUGOU
#  Date du script : 26/05/2024
# -----------------------------------------------

# Definition de la fonction faisant appel a l api
# pour connaitre le nombre de vente a un instant donne pour 
# un modele de carte

get_nombre_ventes() {
   
	carte=$1
        requete="http://0.0.0.0:5000/$carte"	
	reponse_curl=$(curl $requete)
	
	# Sauvegarde du resultat dans le fichier sales.txt
	echo "$carte : $reponse_curl" >> /home/ubuntu/exam_MADOUGOU/exam_bash/sales.txt
		
}



# Initialisation d une variable de type tableau avec les modeles de cartes
modeles_cartes[0]="rtx3060"
modeles_cartes[1]="rtx3070"
modeles_cartes[2]="rtx3080"
modeles_cartes[3]="rtx3090"
modeles_cartes[4]="rx6700"



# Boucle sur une fonction permettant  d executer l api pour -------------------------------------
# savoir le nombre de cartes vendues pour un modele specifique ----------------------------------


# Date de scraping

echo "Date de scraping $(date)" >> /home/ubuntu/exam_MADOUGOU/exam_bash/sales.txt

for i in 0 1 2 3 4
do 	
   carte=${modeles_cartes[$i]}
   get_nombre_ventes $carte
done

# Rajout d un espace
echo "" >> /home/ubuntu/exam_MADOUGOU/exam_bash/sales.txt


